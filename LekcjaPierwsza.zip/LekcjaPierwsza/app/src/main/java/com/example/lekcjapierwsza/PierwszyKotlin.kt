package com.example.lekcjapierwsza

fun main(){
    print("Napisz coś: ")
    val dane : String = readln()
    println("Twój napis ma " +dane.length+ " znaków")

    print("Napisz coś: ")
    val dane2 = readln()
    when (dane2){
        "pomidor" -> println("pomidor")
        "truskawka" -> println("truskawka")
        else -> {
            println("To nie jest ani truskawka ani pomidor")
        }
    }
}